import java.io.*;
/** VERSION 1 - the class as it was when the file was saved (no phone). */
public class Resident implements Serializable {
    private static final long serialVersionUID = 1L;
    String name, regNo;
    Resident(String n, String r) { name = n; regNo = r; }
    public static void main(String[] a) throws Exception {
        try (ObjectOutputStream o = new ObjectOutputStream(new FileOutputStream("resident.ser"))) { o.writeObject(new Resident("Arun", "192311001")); }
        System.out.println("v1: wrote resident.ser");
    }
}
