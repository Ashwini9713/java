import java.io.*;
/** VERSION 2 - phone field added AFTER files were saved. UID is rewritten by run_a4_versioning.sh to test both cases. */
public class Resident implements Serializable {
    private static final long serialVersionUID = 1L;
    String name, regNo, phone;          // NEW field
    public static void main(String[] a) throws Exception {
        try (ObjectInputStream i = new ObjectInputStream(new FileInputStream("resident.ser"))) {
            Resident r = (Resident) i.readObject();
            System.out.println("v2: read OK -> " + r.name + ", " + r.regNo + ", phone=" + r.phone + " (default null)");
        } catch (InvalidClassException e) { System.out.println("v2: FAILED -> " + e); }
    }
}
